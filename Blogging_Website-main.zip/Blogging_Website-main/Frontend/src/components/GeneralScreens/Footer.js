import React from 'react';
import '../../Css/Footer.css'

const Footer = () => {
    return (
        <div>
            <div className="footer">
            </div>
            <div className="copyright">
                <p className="copyright-blog">Created By:</p>
                <p className="copyright-blog">Shubham Mishra</p>
                <p className="copyright-blog">Sagar</p>
                <p className="copyright-blog">Kaushik</p>
            </div>
        </div>
    )
}

export default Footer;
