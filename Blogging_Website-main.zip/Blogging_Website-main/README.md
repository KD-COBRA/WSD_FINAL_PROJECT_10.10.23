# Blogging_Website

Give values in .env inside Config folder
